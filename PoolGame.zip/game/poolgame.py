import pygame
import pymunk
import pymunk.pygame_util
import math
pygame.init()  # set the pygame ready

width = 1200  # width of the screen
height = 640  # height of the screen
panel = 50  # panel of the screen
screen = pygame.display.set_mode((width, height + panel))  # set the screen size
pygame.display.set_caption("EDRES - Pool Game")  # giving a name to the game

clock = pygame.time.Clock()
FPS = 120  # frame per sec
BG = (1, 1, 1)  # background color
hitting = 36
shoot = True
force = 0
power = False
pock = 66
pott = []
game_over = False  # Flag for game over state

cue_image = pygame.image.load('assets/images/cue.png').convert_alpha()
t_image = pygame.image.load('assets/images/table.png').convert_alpha()  # background picture
balls_images = []
for imo in range(1, 17):
    ball_image = pygame.image.load(f'assets/images/ball_{imo}.png').convert_alpha()
    balls_images.append(ball_image)

space = pymunk.Space()
static_body = space.static_body
draw_options = pymunk.pygame_util.DrawOptions(screen)

def create_ball(radius, pos):
    body = pymunk.Body()
    body.position = pos
    shape = pymunk.Circle(body, radius)
    shape.mass = 5
    shape.elasticity = 0.8
    move = pymunk.PivotJoint(static_body, body, (0, 0), (0, 0))
    move.max_bias = 0
    move.max_force = 1000
    space.add(body, shape, move)
    return shape

def reset_game():
    global balls, balls_images, force, power, game_over
    balls = []
    balls_images.clear()
    rows = 5
    for e in range(5):
        for row in range(rows):
            pos = (250 + (e * hitting), 267 + (row * hitting) + (e * hitting / 2))
            new_ball = create_ball(hitting / 2, pos)
            balls.append(new_ball)
        rows -= 1

    cue_ball_start_pos = (888, height / 2)  # Store the initial position of the cue ball
    new1_ball = create_ball(hitting / 2, cue_ball_start_pos)  # Create the white ball
    balls.append(new1_ball)

    for imo in range(1, 17):
        ball_image = pygame.image.load(f'assets/images/ball_{imo}.png').convert_alpha()
        balls_images.append(ball_image)
    
    force = 0
    power = False
    game_over = False

reset_game()

pockets = [
    (55, 63),
    (592, 48),
    (1134, 64),
    (55, 616),
    (592, 629),
    (1134, 616)
]

borders = [
    [(88, 56), (109, 77), (555, 77), (564, 56)],
    [(621, 56), (630, 77), (1081, 77), (1102, 56)],
    [(89, 621), (110, 600), (556, 600), (564, 621)],
    [(622, 621), (630, 600), (1081, 600), (1102, 621)],
    [(56, 96), (77, 117), (77, 560), (56, 581)],
    [(1143, 96), (1122, 117), (1122, 560), (1143, 581)]
]

def create_border(barrier):
    body = pymunk.Body(body_type=pymunk.Body.STATIC)
    body.position = ((0, 0))
    shape = pymunk.Poly(body, barrier)
    shape.elasticity = 0.8
    space.add(body, shape)

for i in borders:
    create_border(i)

class Cue:
    def __init__(self, pos):
        self.original_image = cue_image
        self.angle = 0
        self.image = pygame.transform.rotate(self.original_image, self.angle)
        self.rect = self.image.get_rect()
        self.rect.center = pos

    def update(self, angle):
        self.angle = angle

    def draw(self, surface):
        self.image = pygame.transform.rotate(self.original_image, self.angle)
        surface.blit(self.image,
                     (
                         self.rect.centerx - self.image.get_width() / 2,
                         self.rect.centery - self.image.get_height() / 2
                     ))

cue = Cue(balls[-1].body.position)

def draw_game_over():
    # Create buttons and display the game over message
    font = pygame.font.SysFont(None, 75)
    game_over_text = font.render("GAME OVER", True, (255, 0, 0))
    screen.blit(game_over_text, (width//2 - game_over_text.get_width()//2, height//2 - 100))

    # Draw Restart and End Game buttons
    button_font = pygame.font.SysFont(None, 50)
    restart_button = pygame.Rect(width//2 - 150, height//2 + 50, 300, 60)
    end_button = pygame.Rect(width//2 - 150, height//2 + 130, 300, 60)

    pygame.draw.rect(screen, (0, 255, 0), restart_button)
    restart_text = button_font.render("Restart Game", True, (0, 0, 0))
    screen.blit(restart_text, (restart_button.x + 40, restart_button.y + 10))

    pygame.draw.rect(screen, (255, 0, 0), end_button)
    end_text = button_font.render("End Game", True, (0, 0, 0))
    screen.blit(end_text, (end_button.x + 80, end_button.y + 10))

    return restart_button, end_button
cue_ball_start_pos = (888, height / 2)  # Store the initial position of the cue ball
run = True
while run:
    screen.fill(BG)
    screen.blit(t_image, (0, 0))

    if game_over:
        restart_button, end_button = draw_game_over()

        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse_pos = pygame.mouse.get_pos()
                if restart_button.collidepoint(mouse_pos):
                    reset_game()  # Restart the game
                elif end_button.collidepoint(mouse_pos):
                    run = False  # End the game
            if event.type == pygame.QUIT:
                run = False
        pygame.display.update()
        continue  # Skip the rest of the loop during game over

    shoot = True
    for ball in balls:
        if int(ball.body.velocity[0]) != 0 or int(ball.body.velocity[1]) != 0:
            shoot = False

    if shoot:
        mouse_pos = pygame.mouse.get_pos()
        cue.rect.center = balls[-1].body.position
        x_dist = balls[-1].body.position[0] - mouse_pos[0]
        y_dist = -(balls[-1].body.position[1] - mouse_pos[1])
        cue_angle = math.degrees(math.atan2(y_dist, x_dist))
        cue.update(cue_angle)
        cue.draw(screen)

    if power:
        force += 100
    if not power and shoot:
        x_impulse = math.cos(math.radians(cue_angle))
        y_impulse = math.sin(math.radians(cue_angle))
        balls[-1].body.apply_impulse_at_local_point((force * -x_impulse, force * y_impulse), (0, 0))

    for b, imo in enumerate(balls):
        screen.blit(balls_images[b], (imo.body.position[0] - imo.radius, imo.body.position[1] - imo.radius))

    for i, ball in enumerate(balls):
        for pocket in pockets:
            ball_x_dist = abs(ball.body.position[0] - pocket[0])
            ball_y_dist = abs(ball.body.position[1] - pocket[1])
            ball_dist = math.sqrt((ball_x_dist ** 2) + (ball_y_dist ** 2))

            if ball_dist <= pock / 2:
                if i == 7:  # If the black ball (ball 8) is pocketed
                    game_over = True
                elif i == len(balls) - 1:  # If the white ball (cue ball) is pocketed
                    ball.body.position = cue_ball_start_pos  # Reset the white ball to its starting position
                    ball.body.velocity = (0.0, 0.0)  # Stop the ball from moving
                else:
                    space.remove(ball.body)
                    balls.remove(ball)
                    pott.append(balls_images[i])
                    balls_images.pop(i)

    # If only the white ball remains, it's game over
    if len(balls) == 1 and not game_over:
        game_over = True

    for event in pygame.event.get():
        if event.type == pygame.MOUSEBUTTONDOWN and shoot:
            power = True
        if event.type == pygame.MOUSEBUTTONUP and shoot:
            power = False
            x_impulse = math.cos(math.radians(cue_angle))
            y_impulse = math.sin(math.radians(cue_angle))
            balls[-1].body.apply_impulse_at_local_point((force * -x_impulse, force * y_impulse), (0, 0))
            force = 0
        if event.type == pygame.QUIT:
            run = False

    clock.tick(FPS)
    space.step(1 / FPS)
    pygame.display.update()

pygame.quit()
